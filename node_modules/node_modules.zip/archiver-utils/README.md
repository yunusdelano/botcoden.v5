# Archiver Utils [![Build Status](https://travis-ci.org/archiverjs/archiver-utils.svg?branch=master)](https://travis-ci.org/archiverjs/archiver-utils) [![Build status](https://ci.appveyor.com/api/projects/status/7254ojgmlglhqbed/branch/master?svg=true)](https://ci.appveyor.com/project/ctalkington/archiver-utils/branch/master)


## Things of Interest
- [Changelog](https://github.com/archiverjs/archiver-utils/releases)
- [Contributing](https://github.com/archiverjs/archiver-utils/blob/master/CONTRIBUTING.md)
- [MIT License](https://github.com/archiverjs/archiver-utils/blob/master/LICENSE)
