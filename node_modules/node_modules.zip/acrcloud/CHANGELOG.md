## Changelog:

### 1.4.0

- Added TypeScript
- Renamed project from `acrcloud-npm` to `acrcloud-node`
- Moved changelog to its own file.

### 1.1.4

- Fixed an issue with missing form-data npm module.

### 1.1.3

- Removed `crypto` package

### 1.1.0

- Changed idenfity() method to use promises instead of callbacks
- Added better error handling
- Added example files

### 1.0.0

- Initial commit
